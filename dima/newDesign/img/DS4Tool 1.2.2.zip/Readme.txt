Steps to use this tool:

Skip (1-3) if you used DS3 Scp tool and already installed the drivers or used previous version of this tool 

1. Run ScpDriver.exe from Virtual Bus Driver folder
2. Click install 
3. Should show that Bus Device and Bus Driver are installed 

4. Connnect your Dualshock 4 controller through bluetooth or USB (works with default windows driver from microsoft)
5. Start ScpServer.exe
6 It should be started automaticaly when you launch the tool
7. in your devices and printers Xbox 360 Controller should show up
8. You can stop/start the X360 controllers from the tool
9. Supports up to 4 controllers 
10. If controller is found it should show up in the list on top.
11. You might have to download and install official X360 Controller drivers, .Net Framework 4, DirectX Runtime
12. Seems the tool is not comppatible with bluetooth drivers that do not use Microsoft Stack (Toshiba, CSR, etc)